import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/SaveEditedDetails")
public class SaveEditedDetails extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String consigneeName = request.getParameter("consigneeName");
        String consigneeAddress = request.getParameter("consigneeAddress");
        String consigneeState = request.getParameter("consigneeState");
        String consigneeCity = request.getParameter("consigneeCity");
        String consigneePincode = request.getParameter("consigneePincode");
        String consigneeMobile = request.getParameter("consigneeMobile");
        String consigneeEmail = request.getParameter("consigneeEmail");
        String consigneeAltcontact = request.getParameter("altcontact");

        String consignerName = request.getParameter("consignerName");
        String consignerAddress = request.getParameter("consignerAddress");
        String consignerState = request.getParameter("consignerState");
        String consignerCity = request.getParameter("consignerCity");
        String consignerPincode = request.getParameter("consignerPincode");
        String consignerMobile = request.getParameter("consignerMobile");
        String consignerEmail = request.getParameter("consignerEmail");
        String consignerAltcontact = request.getParameter("altContact");

        String product = request.getParameter("product");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        double weight = Double.parseDouble(request.getParameter("weight"));
        String weightType = request.getParameter("weightType");
        String rateAsPer = request.getParameter("rateAsPer");
        double rate = Double.parseDouble(request.getParameter("rate"));
        
        System.out.println("Consignee Alt Contact: " + consigneeAltcontact);
        System.out.println("Consigner Alt Contact: " + consignerAltcontact);

        
        // Setting attributes to pass to GenerateBillServlet or JSP
        request.setAttribute("consigneeName", consigneeName);
        request.setAttribute("consigneeAddress", consigneeAddress);
        request.setAttribute("consigneeState", consigneeState);
        request.setAttribute("consigneeCity", consigneeCity);
        request.setAttribute("consigneePincode", consigneePincode);
        request.setAttribute("consigneeMobile", consigneeMobile);
        request.setAttribute("consigneeEmail", consigneeEmail);
        request.setAttribute("consigneeAltContact", consigneeAltcontact);

        request.setAttribute("consignerName", consignerName);
        request.setAttribute("consignerAddress", consignerAddress);
        request.setAttribute("consignerState", consignerState);
        request.setAttribute("consignerCity", consignerCity);
        request.setAttribute("consignerPincode", consignerPincode);
        request.setAttribute("consignerMobile", consignerMobile);
        request.setAttribute("consignerEmail", consignerEmail);
        request.setAttribute("consignerAltContact", consignerAltcontact);

        request.setAttribute("product", product);
        request.setAttribute("quantity", quantity);
        request.setAttribute("weight", weight);
        request.setAttribute("weightType", weightType);
        request.setAttribute("rateAsPer", rateAsPer);
        request.setAttribute("rate", rate);

        // Database connection and insertion logic
        try (Connection conn = JdbcUtil.getDBConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO shipment_details "
                 + "(consignee_name, consignee_address, consignee_state, consignee_city, consignee_pincode, consignee_mobile, consignee_email, consignee_alt_contact, "
                 + "consigner_name, consigner_address, consigner_state, consigner_city, consigner_pincode, consigner_mobile, consigner_email, consigner_alt_contact, "
                 + "product, quantity, weight, weight_type, rate_as_per, rate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {

            // Setting parameters for consignee details
            ps.setString(1, consigneeName);
            ps.setString(2, consigneeAddress);
            ps.setString(3, consigneeState);
            ps.setString(4, consigneeCity);
            ps.setString(5, consigneePincode);
            ps.setString(6, consigneeMobile);
            ps.setString(7, consigneeEmail);
            ps.setString(8, consigneeAltcontact);

            // Setting parameters for consigner details
            ps.setString(9, consignerName);
            ps.setString(10, consignerAddress);
            ps.setString(11, consignerState);
            ps.setString(12, consignerCity);
            ps.setString(13, consignerPincode);
            ps.setString(14, consignerMobile);
            ps.setString(15, consignerEmail);
            ps.setString(16, consignerAltcontact);

            // Setting parameters for product details
            ps.setString(17, product);
            ps.setInt(18, quantity);
            ps.setDouble(19, weight);
            ps.setString(20, weightType);
            ps.setString(21, rateAsPer);
            ps.setDouble(22, rate);

            // Execute insert
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
            return;
        }

        request.getRequestDispatcher("GenerateBillServlet").forward(request, response);
   
    }
}


