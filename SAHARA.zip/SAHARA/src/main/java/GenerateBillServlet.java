import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
//import java.text.NumberFormat;
//import java.util.Locale;

@WebServlet("/GenerateBillServlet")
public class GenerateBillServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	// Retrieve consignee details using getAttribute
    	String consigneeName = (String) request.getAttribute("consigneeName");
    	String consigneeAddress = (String) request.getAttribute("consigneeAddress");
    	String consigneeState = (String) request.getAttribute("consigneeState");
    	String consigneeCity = (String) request.getAttribute("consigneeCity");
    	String consigneePincode = (String) request.getAttribute("consigneePincode");
    	String consigneeMobile = (String) request.getAttribute("consigneeMobile");
    	String consigneeEmail = (String) request.getAttribute("consigneeEmail");
    	String consigneeAltContact = (String) request.getAttribute("consigneeAltContact");

    	// Retrieve consigner details using getAttribute
    	String consignerName = (String) request.getAttribute("consignerName");
    	String consignerAddress = (String) request.getAttribute("consignerAddress");
    	String consignerState = (String) request.getAttribute("consignerState");
    	String consignerCity = (String) request.getAttribute("consignerCity");
    	String consignerPincode = (String) request.getAttribute("consignerPincode");
    	String consignerMobile = (String) request.getAttribute("consignerMobile");
    	String consignerEmail = (String) request.getAttribute("consignerEmail");
    	String consignerAltContact = (String) request.getAttribute("consignerAltContact");

    	// Retrieve product details using getAttribute
    	String product = (String) request.getAttribute("product");
    	int quantity = (int) request.getAttribute("quantity");
    	double weight = (double) request.getAttribute("weight");
    	String weightType = (String) request.getAttribute("weightType");
    	String rateAsPer = (String) request.getAttribute("rateAsPer");
    	double rate = (double) request.getAttribute("rate");
//    	double totalCost = (double) request.getAttribute("totalCost");

        
        // Define rates for different products
        rate = 0.0;
        switch (product) {
            case "cement":
                rate = 500.0; // Example rate for cement
                break;
            case "bricks":
                rate = 700.0; // Example rate for bricks
                break;
            case "stones":
                rate = 900.0; // Example rate for stones
                break;
            case "sand":
                rate = 300.0; // Example rate for sand
                break;
            case "paintings":
                rate = 1500.0; // Example rate for paintings
                break;
            case "waterDrums":
                rate = 250.0; // Example rate for water drums
                break;
            case "packages":
                rate = 100.0; // Example rate for packages
                break;
            case "reinforcingBarks":
                rate = 400.0; // Example rate for reinforcing barks
                break;
            default:
                // Handle unknown product case if needed
                break;
        }

//        // Calculate total cost
//        double totalCost = rate * quantity;
//
//        // Manually format the total cost as Indian currency (₹)
//        String formattedTotalCost = String.format("₹%.2f", totalCost);
//        String totalCostStr = "₹60000.00";
//        totalCostStr = totalCostStr.replace("₹", "").trim();
//        double totalCost = Double.parseDouble(totalCostStr);
        double totalCost = rate * quantity;

        // Set attributes for consignee details
        request.setAttribute("consigneeName", consigneeName);
        request.setAttribute("consigneeAddress", consigneeAddress);
        request.setAttribute("consigneeState", consigneeState);
        request.setAttribute("consigneeCity", consigneeCity);
        request.setAttribute("consigneePincode", consigneePincode);
        request.setAttribute("consigneeMobile", consigneeMobile);
        request.setAttribute("consigneeEmail", consigneeEmail);
        request.setAttribute("consigneeAltContact", consigneeAltContact);

        // Set attributes for consigner details
        request.setAttribute("consignerName", consignerName);
        request.setAttribute("consignerAddress", consignerAddress);
        request.setAttribute("consignerState", consignerState);
        request.setAttribute("consignerCity", consignerCity);
        request.setAttribute("consignerPincode", consignerPincode);
        request.setAttribute("consignerMobile", consignerMobile);
        request.setAttribute("consignerEmail", consignerEmail);
        request.setAttribute("consignerAltContact", consignerAltContact);

        // Set attributes for product details
        request.setAttribute("product", product);
        request.setAttribute("quantity", quantity);
        request.setAttribute("weight", weight);
        request.setAttribute("weightType", weightType);
        request.setAttribute("rateAsPer", rateAsPer);
        request.setAttribute("rate", rate);
        request.setAttribute("totalCost", totalCost);

        // Forward to JSP to display the bill
        request.getRequestDispatcher("billForm.jsp").forward(request, response);
    }
}
