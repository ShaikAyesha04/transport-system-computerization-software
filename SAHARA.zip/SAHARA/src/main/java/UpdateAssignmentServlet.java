import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/UpdateAssignmentServlet")
public class UpdateAssignmentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int billId = Integer.parseInt(request.getParameter("billId"));
        String action = request.getParameter("action");
        boolean isAssigned = "agree".equals(action);

        try (Connection conn = JdbcUtil.getDBConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE bill_details SET is_assigned = ? WHERE id = ?")) {
            ps.setBoolean(1, isAssigned);
            ps.setInt(2, billId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Error: " + e.getMessage());
            return;
        }

        response.sendRedirect("displaymanager.jsp"); // Redirect to refresh the list
    }
}
