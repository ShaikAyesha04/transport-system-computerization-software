import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.UnitValue;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.HorizontalAlignment;

import java.io.IOException;
import java.io.OutputStream;

@WebServlet("/DownloadReceipt")
public class DownloadReceipt extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve parameters from the request
        String product = request.getParameter("product");
        String quantity = request.getParameter("quantity");
        String totalCost = request.getParameter("totalCost");
        String consigneeName = request.getParameter("consigneeName");
        String consigneeAddress = request.getParameter("consigneeAddress");
        String consigneeState = request.getParameter("consigneeState");
        String consigneeCity = request.getParameter("consigneeCity");
        String consigneePincode = request.getParameter("consigneePincode");
        String consigneeMobile = request.getParameter("consigneeMobile");
        String consigneeEmail = request.getParameter("consigneeEmail");
        String consigneeAltContact = request.getParameter("consigneeAltContact");
        
        String consignerName = request.getParameter("consignerName");
        String consignerAddress = request.getParameter("consignerAddress");
        String consignerState = request.getParameter("consignerState");
        String consignerCity = request.getParameter("consignerCity");
        String consignerPincode = request.getParameter("consignerPincode");
        String consignerMobile = request.getParameter("consignerMobile");
        String consignerEmail = request.getParameter("consignerEmail");
        String consignerAltContact = request.getParameter("consignerAltContact");
        
        String weight = request.getParameter("weight");
        String weightType = request.getParameter("weightType");
        String rateAsPer = request.getParameter("rateAsPer");
        String rate = request.getParameter("rate");

        // Set response headers for file download
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=receipt.pdf");

        // Create PDF document
        try (OutputStream out = response.getOutputStream()) {
            PdfWriter writer = new PdfWriter(out);
            PdfDocument pdfDoc = new PdfDocument(writer);
            Document document = new Document(pdfDoc);
            
            // Add title and header
            document.add(new Paragraph("SAHARA IMPORTS").setBold().setFontSize(24).setTextAlignment(TextAlignment.CENTER));
            document.add(new Paragraph("Official Receipt").setBold().setFontSize(18).setTextAlignment(TextAlignment.CENTER));
            document.add(new Paragraph("Address: 1234 Example St, City, State, Zip").setTextAlignment(TextAlignment.CENTER));
            document.add(new Paragraph("Contact: +1 (234) 567-8900 | Email: info@saharaimports.com").setTextAlignment(TextAlignment.CENTER));
            document.add(new Paragraph("----------------------------------------------------"));

            // Create a table for Consignee and Consigner Information
            Table infoTable = new Table(UnitValue.createPercentArray(2)).useAllAvailableWidth();
            infoTable.addCell(new Paragraph("Consignee Information").setBold());
            infoTable.addCell(new Paragraph("Consigner Information").setBold());

            infoTable.addCell(new Paragraph("Name: " + consigneeName));
            infoTable.addCell(new Paragraph("Name: " + consignerName));
            infoTable.addCell(new Paragraph("Address: " + consigneeAddress + ", " + consigneeCity + ", " + consigneeState + ", " + consigneePincode));
            infoTable.addCell(new Paragraph("Address: " + consignerAddress + ", " + consignerCity + ", " + consignerState + ", " + consignerPincode));
            infoTable.addCell(new Paragraph("Mobile: " + consigneeMobile));
            infoTable.addCell(new Paragraph("Mobile: " + consignerMobile));
            infoTable.addCell(new Paragraph("Email: " + consigneeEmail));
            infoTable.addCell(new Paragraph("Email: " + consignerEmail));

            document.add(infoTable);
            document.add(new Paragraph("----------------------------------------------------"));

            // Create a table for order details
            Table orderTable = new Table(UnitValue.createPercentArray(2)).useAllAvailableWidth();
            orderTable.addCell(new Paragraph("Product Details").setBold());
            orderTable.addCell(new Paragraph(""));
            
            orderTable.addCell("Product Name:");
            orderTable.addCell(product);
            orderTable.addCell("Quantity:");
            orderTable.addCell(quantity);
            orderTable.addCell("Total Cost:");
            orderTable.addCell("$" + totalCost);
            orderTable.addCell("Weight:");
            orderTable.addCell(weight + " " + weightType);
            orderTable.addCell("Rate As Per:");
            orderTable.addCell(rateAsPer);
            orderTable.addCell("Rate:");
            orderTable.addCell(rate);

            document.add(orderTable);
            document.add(new Paragraph("----------------------------------------------------"));
            
            // Footer with company name and signature line
            document.add(new Paragraph("Thank you for choosing Sahara Imports!").setTextAlignment(TextAlignment.CENTER));
            document.add(new Paragraph("\n\nAuthorized Signature").setTextAlignment(TextAlignment.RIGHT));
            document.add(new Paragraph("____________________________").setTextAlignment(TextAlignment.RIGHT));
            document.add(new Paragraph("Sahara Imports Official").setTextAlignment(TextAlignment.RIGHT));

            document.close();
        }
    }
}
