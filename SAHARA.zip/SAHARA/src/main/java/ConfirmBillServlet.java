import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/ConfirmBillServlet")
public class ConfirmBillServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve all parameters from the request
        String product = request.getParameter("product");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        double totalCost = Double.parseDouble(request.getParameter("totalCost"));
        String consigneeName = request.getParameter("consigneeName");
        String consigneeAddress = request.getParameter("consigneeAddress");
        String consigneeState = request.getParameter("consigneeState");
        String consigneeCity = request.getParameter("consigneeCity");
        String consigneePincode = request.getParameter("consigneePincode");
        String consigneeMobile = request.getParameter("consigneeMobile");
        String consigneeEmail = request.getParameter("consigneeEmail");
        String consigneeAltContact = request.getParameter("consigneeAltContact");
        String consignerName = request.getParameter("consignerName");
        String consignerAddress = request.getParameter("consignerAddress");
        String consignerState = request.getParameter("consignerState");
        String consignerCity = request.getParameter("consignerCity");
        String consignerPincode = request.getParameter("consignerPincode");
        String consignerMobile = request.getParameter("consignerMobile");
        String consignerEmail = request.getParameter("consignerEmail");
        String consignerAltContact = request.getParameter("consignerAltContact");
        double weight = Double.parseDouble(request.getParameter("weight"));
        String weightType = request.getParameter("weightType");
        String rateAsPer = request.getParameter("rateAsPer");
        double rate = Double.parseDouble(request.getParameter("rate"));

        // Database connection and insertion logic
        try (Connection conn = JdbcUtil.getDBConnection();
             PreparedStatement ps = conn.prepareStatement("INSERT INTO bill_details (product, quantity, total_cost, consignee_name, consignee_address, consignee_state, consignee_city, consignee_pincode, consignee_mobile, consignee_email, consignee_alt_contact, consigner_name, consigner_address, consigner_state, consigner_city, consigner_pincode, consigner_mobile, consigner_email, consigner_alt_contact, weight, weight_type,rate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")) {
            
            // Set parameters for the prepared statement
            ps.setString(1, product);
            ps.setInt(2, quantity);
            ps.setDouble(3, totalCost);
            ps.setString(4, consigneeName);
            ps.setString(5, consigneeAddress);
            ps.setString(6, consigneeState);
            ps.setString(7, consigneeCity);
            ps.setString(8, consigneePincode);
            ps.setString(9, consigneeMobile);
            ps.setString(10, consigneeEmail);
            ps.setString(11, consigneeAltContact);
            ps.setString(12, consignerName);
            ps.setString(13, consignerAddress);
            ps.setString(14, consignerState);
            ps.setString(15, consignerCity);
            ps.setString(16, consignerPincode);
            ps.setString(17, consignerMobile);
            ps.setString(18, consignerEmail);
            ps.setString(19, consignerAltContact);
            ps.setDouble(20, weight);
            ps.setString(21, weightType);
            ps.setDouble(22, rate);

            ps.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception (e.g., log error, show error message, etc.)
        }

        // Set attributes for the confirmation page
        request.setAttribute("product", product);
        request.setAttribute("quantity", quantity);
        request.setAttribute("totalCost", totalCost);
        request.setAttribute("consigneeName", consigneeName);
        request.setAttribute("consigneeAddress", consigneeAddress);
        request.setAttribute("consigneeState", consigneeState);
        request.setAttribute("consigneeCity", consigneeCity);
        request.setAttribute("consigneePincode", consigneePincode);
        request.setAttribute("consigneeMobile", consigneeMobile);
        request.setAttribute("consigneeEmail", consigneeEmail);
        request.setAttribute("consigneeAltContact", consigneeAltContact);
        request.setAttribute("consignerName", consignerName);
        request.setAttribute("consignerAddress", consignerAddress);
        request.setAttribute("consignerState", consignerState);
        request.setAttribute("consignerCity", consignerCity);
        request.setAttribute("consignerPincode", consignerPincode);
        request.setAttribute("consignerMobile", consignerMobile);
        request.setAttribute("consignerEmail", consignerEmail);
        request.setAttribute("consignerAltContact", consignerAltContact);
        request.setAttribute("weight", weight);
        request.setAttribute("weightType", weightType);
        request.setAttribute("rateAsPer", rateAsPer);
        request.setAttribute("rate", rate);

        // Forward to confirmation page
        request.getRequestDispatcher("confirmation.jsp").forward(request, response);
    }
}
